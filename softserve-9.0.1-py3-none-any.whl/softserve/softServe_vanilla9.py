###SOFTSERVE SOFTWARE SERVER V9
###CHANGELOG:

# Changed the default channel list from 320 - 330 to 1 to 10.

import socket
import threading
import time

###CHANNELS class

class CHANNELS():

    #__INIT__ function: This sets up the CHANNELS object upon instantiation (however that's spelled) with all of the proper values and variables
    def __init__(self):
        #Whether or not the UDP server prints out semi-useful output. What? It might prove useful to someone eventually...
        self.__verbosity = False

        #The dictionary containing the local channels. Change the numbers here to add or subtract channels
        self.__channelList = {
        "1" : "Null", "2": "Null",
        "3" : "Null", "4" : "Null",
        "5" : "Null", "6" : "Null",
        "7" : "Null", "8" : "Null",
        "9" : "Null", "10" : "Null",
        }

        #Get the ip of this machine using getMyIP function
        #A bit of a caveat here - This may not automatically get the right ip if this computer is connected to multiple networks
        self.myIP = self.__getMyIP()

        #Define the port that this server will use for communication here. Change this and it will use that port
        self.__UDP_PORT = 6000

        #Create udp socket for communication
        self.__sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        #Tell the socket to reuse an existing address if it is available. This is to counter the "Adress already in use" error
        self.__sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        #Create the recv_udp subthread. This means that when we call self.__recvSubThread.start() it will launch the recv_udp function in an independent thread that's independent from the main program (However uses and maintains the same variables as the main program)
        #The daemon=True sets this thread to stop whenever the main program gets killed.
        self.__recvSubThread = threading.Thread(target = self.__recv_udp, daemon=True)

        #How long this server will wait for feedback from another server before it gives up. Time is in seconds (0.5 is half a second, cetera)
        self.feedbackWaitLimit = 3.0

        #remoteServerFeedback: This variable acts as an intermediary between the getRemoteChannel function, which returns the value of a channel on a remote server, and the recv_udp subthread.
        self.__remoteServerFeedback = ""

        #invalidChannelNumberError: This is the "error" string we send to a client who tried using a channel number we don't have
        self.__invalidChannelNumberError = "%INVCHANUM%"

        self.__isServerOpen = False

        #SHORTCUTS: These make the main functions in this module callable using 3 letters instead of who knows how many.
        #For example, channelClass.getRemoteChannel() will function the same as channelCLass.GRC()

        #A user can now call the getRemoteChannel and setRemoteChannel with channelClass.GRC() and channelClass.SRC() respectively
        self.GRC = self.getRemoteChannel
        self.SRC = self.setRemoteChannel

        #Same goes for local channel commands
        self.GLC = self.getLocalChannel
        self.SLC = self.setLocalChannel

        #And the server starter
        self.OUS = self.openUDPServer

        #And the returnChannelList as well
        self.RCL = self.returnChannelList

        #And verbosity
        self.VBT = self.verbosityToggle

        #And channel list generation
        self.CCL = self.createChannelList

    #This is the function that toggles verbosity on and off
    #I have it here mostly to give us some meta verbosity like turning verbosity on, turning verbosity off
    def verbosityToggle(self):
        if self.__verbosity == True:
            self.__verbosity = False
            print("Turning off verbosity...")
        else:
            self.__verbosity = True
            print("Turning on verbosity...")


    def createChannelList(self, start, stop, defaultValue):
        if self.__isServerOpen == False:
            newChannelList = {}
            for numID in range(start, stop + 1):
                newChannelList[str(numID)] = str(defaultValue)

            self.__channelList = newChannelList

    #GETMYIP function:
    #Returns an ip adress that this server is using.
    #Note that this may not always return the proper ip if the machine that this is running on has muliple network connections (i.e. Internal wireless + usb dongle or Internal wireless + ethernet cable)
    def __getMyIP(self):
        #Create a dummy socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        #Connect to a dummy ip address and port
        s.connect(("8.8.8.8", 80))
        #Get the ip address that we just used to connect to that dummy port
        myIP = (s.getsockname()[0])
        #Close the dummy socket
        s.close()
        return myIP

    #SEND_UDP function:
    #This is the generic function used to send udp commands to other servers
    def __send_udp(self, UDP_ip, UDP_data):

        # Send a udp >>>>>>>>>>
        self.__sock.sendto(UDP_data.encode('utf-8'), (UDP_ip, self.__UDP_PORT))

    #RECV_UDP function:
    #This is out main server loop. This function is operated in a seperate dedicated thread so it can constantly wait for a response without holding up the rest of the program.
    #It also interprets any string data receives and forwards it to the proper functions if it deems the received string to be a command.
    def __recv_udp(self):
        while True:
            #Wait and listen for a response. When received, update the data and addr variables
            primaryData, addr = self.__sock.recvfrom(1024)
            #Extract the client's ip from the addr variable that is naturally attached to any UDP command we receive
            clientIP = addr[0]
            #Decode data from UTF-8 back into a regular string (UTF-8 encoded strings have an annoying b in front of them however encoding them is necessary for python 3 socket networking to like them)
            primaryData = primaryData.decode('UTF-8')

            #If the verbosity has been turned on, print out the raw data we have received
            if self.__verbosity:
                print(primaryData)

            #Split the initial data list into seperate commands by pipes | into sub commands the user want's to chain
            primaryDataList = [x.strip() for x in primaryData.split("|")]

            #Iterate thought the sub commands
            for secondaryData in primaryDataList:

                #Split the string into a list by spaces i.e "This is a string" will be turned into ["This", "is", "a", "string"]
                secondaryDataList = secondaryData.split(" ")

                #If the verbosity has been turned on, print out this list
                if self.__verbosity:
                    print(secondaryDataList)

                #If the dataList's first item is either "sc" or "SC" then we know we have received a set channel command
                if secondaryDataList[0] == "sc" or secondaryDataList[0] == "SC":
                    #Check whether or not the list is long enough to be a valid set channel command (should be at least "COMMAND", "CHANNEL", "VALUE")
                    if len(secondaryDataList) >= 3:
                        #Forward the data to the setChannel function
                        self.__setChannel(secondaryDataList, clientIP)

                #If the dataList's first item is either "gc" or "GC" then we know we have received a get channel command
                elif secondaryDataList[0] == "gc" or secondaryDataList[0] == "GC":
                    #Check whether or not the list is long enough to ba a valid get channel command (should be at least "COMMAND", "CHANNEL")
                    if len(secondaryDataList) >= 2:
                        #Forward the data to the getChannel function
                        self.__giveChannel(secondaryDataList, clientIP)


                else:
                    self.__interpretServerFeedback(secondaryDataList, clientIP)


    #GIVE CHANNEL: This function sends the value of a channel to another server upon the server sending a "GET CHANNEL" command to us
    def __giveChannel(self, dataList, clientIP):
        #If verbosity is turned on, let the user know what's going down in the background
        if self.__verbosity:
            print("We have received a get channel command")
        #Extract the channel number that the client want's to receive the value of from the raw data list
        channelNum = dataList[1]

        #Check if said channel number actually exists here else it's not our problem
        if channelNum in self.__channelList.keys():
            #If verbosity is on, print out what we have just done
            if self.__verbosity:
                print("Sending the value of channel %s to address %s" % (channelNum, clientIP))

            outputString = "%s" % (self.__channelList[channelNum])

            #Send the signed value of the requested channel to the client
            self.__send_udp(clientIP, outputString)
        #If the person has requested to change the value of a channel we don't have, send them a polite message saying they goofed.
        else:
            if self.__verbosity:
                print("Get Channel has been given an invalid channel number. Are you supposed to provide this channel?")
            self.__send_udp(clientIP, self.__invalidChannelNumberError)


    #SET CHANNEL: This function updates the value of a given channel upon another server sending a "SET CHANNEL" command to us
    def __setChannel(self, dataList, clientIP):

        #If verbosity is turned on, let the user know what's going down in the background
        if self.__verbosity:
            print("We have received a set channel command")

        #Extract the number of the channel that the client has requested to be updated from the datalist
        channelNum = dataList[1]

        #Actually check if said channel exists on this server
        if channelNum in self.__channelList.keys():

            #This loop then assumes that everything after the channel number is the value and stitches it back together, adding in a space between the item until it hits the last item
            value = ""
            position = 0
            for str in dataList[2:]:
                position += 1
                value += str
                if position != len(dataList[2:]):
                    value += " "

            #If verbosity is turned on, oh you get the idea
            if self.__verbosity:
                print("Setting the value of channel %s to %s" % (channelNum, value))

            #Actually update the value of the local channel here
            self.__channelList[channelNum] = value

            if self.__verbosity:
                print(self.__channelList)

        #If the person has requested to change the value of a channel we don't have, send them a polite message saying they goofed.
        else:
            if self.__verbosity:
                print("Set Channel has been given an invalid channel number. Are you sure you are supposed to provide this channel?")
            self.__send_udp(clientIP, self.__invalidChannelNumberError)

    #INTERPRET SERVER FEEDBACK:
    #This function assumes that the string we have received is feedback from another channel server / the value of a channel we have requested from another server and stich it together and save as the global variable
    #remoteServerFeedback. Most of the time this would store any invalid commands or miscelaneous crap sent to us over udp. However, we will look to this variable whenever we query another server using the getRemoteChannel function.
    #Odds are that if this variable is changed within the 3 seconds we wait for a response from a server, it is the value we are looking for. To make doubly sure, we check if this variable has come from the ip we have queried.
    def __interpretServerFeedback(self, dataList, clientIP):

        #Same loop de swoop thing that stitches back together the value we want to see
        value = ""
        position = 0
        for str in dataList:
            position += 1
            value += str
            if position != len(dataList):
                value += " "

        #Update the global remoteServerFeedback variable here
        self.__remoteServerFeedback = (value, clientIP)



    #GET REMOTE CHANNEL:
    #This function is designed to be called from someone else's program whenever they want to get the value of an external server's channel. It will return said value back into someone else's code
    def getRemoteChannel(self, remoteIP, channelNum):
        #If the user has put in the channel number as anything that isn't a string, turn it into a string
        #Putting in any non-numerical input as a channel number can and will break the program. We can't act on invalid input.
        #IDEA: Should we print out an error saying why they screwed up when the program breaks.
        if type(channelNum) != str:
            channelNum = str(channelNum)

        #If the global remoteServerFeedback is not empty, clear it now so if we try to query a non-existant server this function doesn't return a wrong variable
        if self.__remoteServerFeedback != "":
            self.__remoteServerFeedback = ""

        #Create an empty outputVale variable. All this does is store a copy of the global remoteServerFeedback so we can clear it ready for the next use.
        outputValue = ""

        #Redundant comment here is redundant
        if self.__verbosity:
            print("Requesting the value of channel %s in server at %s" % (channelNum, remoteIP))

        #send the request for the value of some other server's channel here in the COMMAND CHANNEL format
        self.__send_udp(remoteIP, "gc %s" % (channelNum))

        #Set the time waited clock variable to 0.0. Yes, there is probably a better way like an actualy timer object or something but this just works
        timeWaited = 0.0

        #Wait for a response from the server until max wait time has been reached
        while timeWaited < self.feedbackWaitLimit:

            #If we have received the external server's feedback via the global remoteServerFeedback variable, stop waiting
            if self.__remoteServerFeedback:
                if self.__verbosity:
                    print("Have received %s as the value of channel %s from server at %s after %s seconds" % (self.__remoteServerFeedback[0], channelNum, self.__remoteServerFeedback[1], timeWaited))

                #Check if the data really has come from the server we have queried
                if remoteIP == self.__remoteServerFeedback[1]:
                    if self.__verbosity:
                        print("This is the data we are looking for")
                    #Make a copy of the global remoteServerFeedback variable here
                    outputValue = self.__remoteServerFeedback[0]
                    break
                else:
                    if self.__verbosity:
                        print("Hold up. This data did not come from the server at %s. It came from %s. Continuing wait for proper feedback" % (remoteIP, self.__remoteServerFeedback[1]))
                    #Empty the false server feedback
                    self.__remoteServerFeedback = ""

            #Wait an increment of 0.01 seconds so that we update the timeWaited variable by time and not space
            time.sleep(0.01)
            #Update how long we have waited by
            timeWaited += 0.01

        #If we never received any feedback whatsoever and the verbosity is on, tell the user
        if not self.__remoteServerFeedback and self.__verbosity:
            print("Failed to get channel from remote server after a %s second wait" % (self.feedbackWaitLimit))
            outputValue = ""


        #Empty out remoteServerFeedback for next time
        self.__remoteServerFeedback = ""

        #Return the value of the requested external channel
        return outputValue

    #SET REMOTE CHANNEL:
    #This function is designed to be use in someone else's code whenever they want to update the value of an external server's channel
    #This is basically a glorified send_udp function however I wanted symmetry since getRemoteChannel got it's own function and I don't trust the user with access directly to the send_udp function
    #which should by all accounts be a strictly internal function
    def setRemoteChannel(self, remoteIP, channelNum, value):
        #If the user has put in the channel number as anything that isn't a string, turn it into a string
        #Putting in any non-numerical input as a channel number can and will break the program. We can't act on invalid input.
        #IDEA: Should we print out an error saying why they screw ed up when the program breaks.
        if type(channelNum) != str:
            channelNum = str(channelNum)

        if self.__verbosity:
            print("Changing the value of channel %s in server at %s to %s" % (channelNum, remoteIP, value))

        #Send the request to the external server to update the channel of our choosing to the value of our choosing
        self.__send_udp(remoteIP, "sc %s %s" % (channelNum, value))

    #GET LOCAL CHANNEL:
    #From our local channel list retrieve the value of a channel by channel number and return it to the user
    def getLocalChannel(self, channelNum):
        #All channel numbers are strings. Turn it into a string just in case the user passed it as an integer
        if type(channelNum) != str:
            channelNum = str(channelNum)
        #If the channel number given by the user is in our dictionary, return the value of that channel
        if channelNum in self.__channelList.keys():
            if self.__verbosity:
                print("Returning the value of local channel ", channelNum)
            return self.__channelList[channelNum]

    #SET LOCAL CHANNEL
    #Update a channel value in our own channel list
    def setLocalChannel(self, channelNum, value):
        #All channel numbers are strings. Turn it into a string just in case the user passed it as an integer
        if type(channelNum) != str:
            channelNum = str(channelNum)
        #If the channel number given by the user is in our dictionary, update that channel
        if channelNum in self.__channelList.keys():
            if self.__verbosity:
                print("Updating the value of local channel %s to %s" % (channelNum, value))
            self.__channelList[channelNum] = value

    #returnChannelList: Prints out the channel list, as I have made it private
    #This is only temporary and added for debugging purposes
    def returnChannelList(self):
        if self.__verbosity:
            print("Displaying a temporary channel dictionary. This will not be updated")
        return dict(zip(self.__channelList.keys(), self.__channelList.values()))


    #OPEN UDP SERVER:
    #This function binds the networking sock to the address and port we want to receive commands with and starts the recvSubThread um thread, essentially opening this server for business.
    #Please. Do us all a favour. If your server or someone elses server is not responding, doube triple quadruple quintuple and team check if you/they have called this function first.
    #Please do not complain if the server is working if you haven't run this command first. Either that or keep complaining to me and eventually I'll cave and make this function
    #run automagically when you make an instance of this class.
    def openUDPServer(self):
        if self.__verbosity:
            print("Opening the UDP server on %s using port %s" % (self.myIP, self.__UDP_PORT))
        #Bind the ip and port for receiving and sending
        self.__sock.bind((self.myIP, self.__UDP_PORT))
        #Start the receiving thread here
        self.__recvSubThread.start()
        self.__isServerOpen = True

    #Returns the version of this module along with a little vanity and catchphrase flaunt.
    #It is kind of redundant if you can see the name of this file in your text editor, however it was added to double check which version of the module any program was using. (Mind you it redundant still if you have that program open and check at the top of the file what you imported. Hm.)
    #You might want to update this when you ever get around to making a flavour of this module
    def getModuleVersion(self):
        print("%s. Written by Lachlan Paulsen and 99.8%% caffine free" % (__name__))

if __name__ == "__main__":
    channelClass = CHANNELS()
